package p5;



abstract public class Stone {

    private String name;
    private int cost;
    private double weight;

    public Stone(String name, int cost,double weight) {
        this.name = name;
        this.cost = cost;
        this.weight= weight;
    }

    public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }

    public double getWeight() {
        return weight;
    }

    abstract public void Selected();
}
