package p5;


import java.util.ArrayList;
import java.util.List;

public class Necklace {

    private String name;
    private List<Stone> stones = new ArrayList<>();

    public Necklace(String name) {
        this.name = name;
    }

    public int getTotalCost(){
        int sum = 0;
        for (Stone s : stones) {
            sum+=s.getCost();
        }
        return sum;

    }

    public double getTotalWeight(){
        double sum = 0;
        for (Stone s : stones) {
            sum+=s.getWeight();
        }
        return sum;

    }

    public void addStone(Stone stone) {
        stones.add(stone);
    }

    public void startWork() {
        stones.forEach(s -> s.Selected());
    }
}
