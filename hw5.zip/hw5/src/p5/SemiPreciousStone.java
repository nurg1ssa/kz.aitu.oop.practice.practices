package p5;

public class SemiPreciousStone extends Stone {

    public SemiPreciousStone(String name, int cost,double weight) {
        super(name, cost, weight);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int getCost() {
        return super.getCost();
    }

    @Override
    public double getWeight() {
        return super.getWeight();
    }

    @Override
    public void Selected() {
        System.out.println("Semi-precious stone "+ getName() +" is selected for necklace");
    }
}
