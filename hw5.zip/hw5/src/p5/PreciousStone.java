package p5;
public class PreciousStone extends Stone{

    public PreciousStone(String name, int cost,double weight) {
        super(name, cost,weight);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int getCost() {
        return super.getCost();
    }

    @Override
    public double getWeight() {
        return super.getWeight();
    }

    @Override
    public void Selected() {
        System.out.println("Precious stone "+ getName() +" is selected for necklace");
    }

}
