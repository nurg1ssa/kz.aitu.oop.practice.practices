package p3;

abstract public class Developer extends Employee {

    public Developer(String name, String surname, String email, int cost) {
        super(name, surname, email, cost);
    }

    @Override
    public int getCost() {
        return super.getCost();
    }
    @Override
    public void work() {
        writeCode();
    }

    abstract void writeCode();
}

