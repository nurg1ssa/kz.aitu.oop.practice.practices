package p3;

public class androidDeveloper extends Developer {

    public androidDeveloper(String name, String surname, String email, int cost) {
        super(name, surname, email, cost);
    }

    @Override
    public int getCost() {
        return super.getCost();
    }

    @Override
    void writeCode() {
        System.out.println("Android App is done");
    }
}
