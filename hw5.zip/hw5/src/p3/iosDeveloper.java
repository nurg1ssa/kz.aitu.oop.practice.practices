package p3;

public class iosDeveloper extends Developer {

    public iosDeveloper(String name, String surname, String email, int cost) {
        super(name, surname, email, cost);
    }

    @Override
    public int getCost() {
        return super.getCost();
    }
    @Override
    void writeCode() {
        System.out.println("IOS application is done");
    }
}
