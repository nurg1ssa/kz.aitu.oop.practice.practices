package p3;

abstract public class Employee {

    private String name;
    private String surname;
    private String email;
    private int cost;

    public Employee(String name, String surname, String email, int cost) {
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.cost = cost;
    }

    public int getCost() {
        return cost;
    }

    abstract public void work();
}
