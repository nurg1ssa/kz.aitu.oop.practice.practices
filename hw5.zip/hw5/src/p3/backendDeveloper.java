package p3;

public class backendDeveloper extends Developer {

    public backendDeveloper(String name, String surname,String email, int cost) {
        super(name, surname, email, cost);
    }

    @Override
    public int getCost() {
        return super.getCost();
    }
    @Override
    void writeCode() {
        System.out.println("Backend is done");
    }
}
