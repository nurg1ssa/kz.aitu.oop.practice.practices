package p3;

public class Designer extends  Employee {

    public Designer(String name, String surname, String email, int cost) {
        super(name, surname, email, cost);
    }

    @Override
    public int getCost() {
        return super.getCost();
    }
    @Override
    public void work() {
        System.out.println("The design is done");
    }
}
