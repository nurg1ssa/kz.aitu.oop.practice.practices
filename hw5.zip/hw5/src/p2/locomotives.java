package p2;

public class locomotives extends transport {

    public locomotives(String name, int passengersNo) {
        super(name, passengersNo);
    }

    @Override
    public int getPassengersNo() {
        return super.getPassengersNo();
    }

    @Override
    public void work() {
        System.out.println("Added to train");
    }
}
