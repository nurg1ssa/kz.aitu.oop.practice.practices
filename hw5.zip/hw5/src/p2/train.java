package p2;


import java.util.ArrayList;
import java.util.List;

public class train {

    private String name;
    private List<transport> transports = new ArrayList<>();

    public train(String name) {
        this.name = name;
    }

    public int getTotalPassengersNo(){
        int sum = 0;
        for (transport t : transports) {
            sum+=t.getPassengersNo();
        }
        return sum;

    }
    public void addLocomotive(transport transport) {
        transports.add(transport);
    }

    public void startWork() {
        transports.forEach(t -> t.work());
    }


}
