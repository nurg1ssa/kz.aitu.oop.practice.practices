package p4;
	import java.sql.*;
	public class MysqlCon{
	    public void add(Animals ani){
	        try{
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oopdb?useUnicode=true&serverTimezone=UTC","root","");
	            Statement stmt=con.createStatement();
	            int rs=stmt.executeUpdate("INSERT INTO `firstdb`( `name`, `price`, `feeded`) VALUES ('"+ani.name+"','"+ani.price+"','"+0+"')");
	            con.close();
	        }catch(Exception e){ System.out.println(e);}
	    }

	    public void updateFeeded(Animals ani, int times){ // if you feed animal this will increase feeded column in db. (Do not work, temporarily not working)
	        try{
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oopdb?useUnicode=true&serverTimezone=UTC","root","");
	            Statement stmt=con.createStatement();
	            int rs=stmt.executeUpdate("UPDATE `firstdb` SET `feeded`='"+(times+1)+"' WHERE name = '"+ani.name+"'");
	            con.close();
	        }catch(Exception e){ System.out.println(e);}

	    }

	    public int getFeed(Animals ani){
	        try{
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oopdb?useUnicode=true&serverTimezone=UTC","root","");
	            Statement stmt=con.createStatement();
	            ResultSet rs=stmt.executeQuery("select feeded from firstdb where name = '"+ani.name+"'");

	            int times = rs.getInt(1);
	            con.close();
	            return times;
	        }catch(Exception e){ System.out.println(e);}
	        return 0;
	    }
	    public void deleteani(Animals ani){
	        try{
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oopdb?useUnicode=true&serverTimezone=UTC","root","");
	            Statement stmt=con.createStatement();
	            int rs=stmt.executeUpdate("DELETE FROM `firstdb` WHERE name = '"+ani.name+"'");
	            con.close();
	        }catch(Exception e){ System.out.println(e);}
	    }
	    public void select(){
	        try{
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oopdb?useUnicode=true&serverTimezone=UTC","root","");
	            Statement stmt=con.createStatement();
	            ResultSet rs=stmt.executeQuery("select * from firstdb");
	            while(rs.next())
	                System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));
	            con.close();
	        }catch(Exception e){ System.out.println(e);}
	    }

	}


