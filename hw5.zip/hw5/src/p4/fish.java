package p4;

public class fish extends Animals{
    public fish(String name, double price) {
        super(name, price);
    }

    @Override

    public void eat() {
        MysqlCon db = new MysqlCon();
        db.updateFeeded(this, db.getFeed(this));
    }

    @Override
    public String sound() {
        return "blop blop";

    }
    @Override
    public String toString() {
        return "Fish's name is "+this.name+" and it's price is" + this.price+"credits.";
    }

}

