package p4;

public class Aquarium {
    protected double price;

    public Aquarium(){
        price = 10.0;
    }

    public void input(Animals ani){
        price = price + ani.price;
        MysqlCon db = new MysqlCon();
        db.add(ani);
    }
    public void output(Animals ani){
        price = price - ani.price;
        MysqlCon db = new MysqlCon();
        db.deleteani(ani);
    }
    public void print(){
        MysqlCon db = new MysqlCon();
        db.select();
    }

    public double getPrice(){
        return price;
    }
}
