package p4;

public interface anInterface {
    public void eat();
    public String sound();
    @Override
    public String toString();
}
