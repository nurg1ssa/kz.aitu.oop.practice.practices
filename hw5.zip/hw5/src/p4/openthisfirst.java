package p4;

	public class openthisfirst {
	    public static void main(String[] args) {
	        Aquarium aqua = new Aquarium();
	        Animals koi = new fish("koi", 5);
	        aqua.input(koi);
	        aqua.getPrice();
	        koi.eat();
	        aqua.print();

	    }
	}

