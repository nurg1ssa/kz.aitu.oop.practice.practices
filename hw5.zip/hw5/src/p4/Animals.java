package p4;


abstract public class Animals implements anInterface {
    protected String name;
    protected double price;

    public Animals(String name, double price){
        this.name = name;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}

