package p4;

public class reptile extends Animals {
    public reptile(String name, double price) {
        super(name, price);
    }

    @Override
    public void eat() {
        MysqlCon db = new MysqlCon();
        db.updateFeeded(this, db.getFeed(this));
    }
    @Override
    public String sound() {
        return "qwa qwa";

    }
    @Override
    public String toString() {
        return "Reptile's name is "+this.name+" and it's price is" + this.price+"credits.";
    }

}
